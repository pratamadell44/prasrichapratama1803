# selfbot-py3

°`DOWNLOAD APP TERMUX DI PLAY STORE YEH`°


INSTALL MODULED :
- KETIK -> `pip install akad`
- KETIK -> `pip install bs4`
- KETIK -> `pip install gTTS`
- KETIK -> `pip install requests`
- KETIK -> `pip install rsa`
- KETK -> `pip install thrift==0.11.0`

#===========================
`-IKUTI DI BAWAH INI-`

- > git clone `https://github.com/zelebez6969/selfbot-py3.git`
- > `cd selfbot-py3`
- > `python3 sbpy3.py`

`nanti muncul link tinggal copy lalu paste ke line dan klik dah buat login 😁`
============================

@zelebez6969
